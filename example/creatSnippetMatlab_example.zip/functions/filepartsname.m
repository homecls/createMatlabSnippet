function fname = filepartsname(file)
% fname = filepartsname(file)
if isstring(file)
   file = cellstr(file); 
end
file = makeitcell(file);
nfile = numel(file);
fname = cell(nfile,1);
for ifile = 1:nfile
    [~,fn,ext] = fileparts(file{ifile});
    fname{ifile} = strcat(fn,ext);
end

end