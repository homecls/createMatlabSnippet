function str = NL(varargin)

nl = sprintf('\n');
if nargin == 0
    str = nl;
else
    str = '';
    for ii=1:varargin{1}
        str = [str, nl];
    end
end

end
