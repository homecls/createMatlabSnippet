function fwriteUTF8(file1,AA1)
% fid = fopen('ExamInv201506.tex','w');
if isnumeric(file1)
    fid = file1;
else
    fid = fopen(file1,'w');
end
fwrite(fid, char(unicode2native(AA1,'UTF-8')));
fclose(fid);
end