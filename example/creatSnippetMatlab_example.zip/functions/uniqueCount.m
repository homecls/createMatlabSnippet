function [uniques,ia,ic,Tvarnamesunique,TvarnamesDuplicate,IDDuplicate] = uniqueCount(varargin)
% [uniques,ia,ic,Tvarnamesunique] = uniqueCount(varargin) 
% FULL Example:
% [uniques,ia,ic,Tvarnamesunique,TvarnamesDuplicate,IDDuplicate] = uniqueCount(T.Name)
% if isempty(IDDuplicate)
%     disp('no duplication are found!')
% else
%     cprintf('key','some duplication are found')
%     T(IDDuplicate,:)
% end


[uniques,ia,ic] = unique(varargin{:}); % {'%';'��Ԫ';'����=100';'��Ԫ';'Ԫ'}
[~,numUnique] = count_unique(ic);
if istable(uniques)
    Tvarnamesunique = uniques;
    Tvarnamesunique.numUnique = numUnique;
else
    Tvarnamesunique = table(uniques,numUnique);
end

TvarnamesDuplicate = Tvarnamesunique(Tvarnamesunique.numUnique>1,:);
varnamesDuplicate = Tvarnamesunique.uniques(Tvarnamesunique.numUnique>1,:);
T = varargin{1};
IDDuplicate = ismember(T, varnamesDuplicate);

% if isempty(IDDuplicate)
%     disp('no duplication are found!')
% else
%     cprintf('key','some duplication are found')
%     T(IDDuplicate,:)
% end

